package SBITeam.dataValidation;
public class IteratorOperations   implements  DataIterator{
	ElementsList   elemlist;
	int count=0;
	
	public IteratorOperations(ElementsList   elist)
	{
		elemlist=elist;
	}
	public  int   next()
	{
		int result=0;
		if(count < elemlist.data.length) {
			result=elemlist.get(count);
			count++;
		}
		return result;
		
	}
	
	public  int   previous()
	{

		int result=0;

		if(count >=0)
		{
			count--;
			result=elemlist.get(count);
		}
		return result;
		
	}
}
