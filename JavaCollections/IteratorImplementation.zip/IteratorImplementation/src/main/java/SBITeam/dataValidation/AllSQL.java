package SBITeam.dataValidation;
import java.sql.*;
import static java.sql.DriverManager.getConnection;
import java.util.*;
import java.io.*;
import java.text.*;
import java.util.*;
public class AllSQL
{
    static Connection ConnTwo;
    static Statement stat;
    static ResultSet rs;
    static Properties PropOne;
    public static void dbTransaction ()
    {
        try
        {
            //Class.forName ("oracle.jdbc.driver.OracleDriver");
            new com.mysql.cj.jdbc.Driver();
            ConnTwo = getConnection ("jdbc:mysql://localhost:3306/world", "root", "root001");
            ConnTwo.setAutoCommit (false);
            stat=ConnTwo.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
            rs=stat.executeQuery("SELECT  * FROM Teams");
            while (rs.next ())
            {
            System.out.print (rs.getString ("TeamID") + " ");
            System.out.print (rs.getString ("TeamName") + " ");
            System.out.print (rs.getString ("HomeCity")+ " ");
            }

       // ConnTwo.close ();
        } catch (SQLException sqle)
        {
            System.out.println (sqle);
        } /*catch (ClassNotFoundException cnfe)
        {
            System.out.println (cnfe);
        }*/
    }
    public static void main (String args[])
    {
        dbTransaction();
    }
}