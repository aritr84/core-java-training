package SBITeam.dataValidation;
public interface DataIterator {
	public int  next();
	public int previous();
}
