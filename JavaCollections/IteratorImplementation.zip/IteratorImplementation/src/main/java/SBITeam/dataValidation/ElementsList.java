package SBITeam.dataValidation;
public class ElementsList {
	int  data[] = {100, 179, 28, 89, 31, 657, 453};
	public int get(int  cnt)
	{
		return  ((cnt < data.length) ? data[cnt]: -1);
	}
	public    DataIterator   getIterator() {
		IteratorOperations  itrops=new IteratorOperations(this);
		return  itrops;
	}
}
