package SBITeam.dataValidation;

public class IteratorMain {

	public static void main(String[] args) {
		ElementsList  elements=new ElementsList();
		DataIterator   dataitr=elements.getIterator();
		System.out.println(dataitr.next());
		System.out.println(dataitr.next());
		System.out.println(dataitr.next());
		System.out.println("--------------Reverse----------------");
		System.out.println(dataitr.previous());
		System.out.println(dataitr.previous());
		System.out.println(dataitr.previous());
	}

}
