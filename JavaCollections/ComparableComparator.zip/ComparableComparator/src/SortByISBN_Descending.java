import java.util.Comparator;

public class SortByISBN_Descending implements Comparator<Book> {

	@Override
	public int compare(Book o1, Book o2) {
		//Sorting condition. Not the algorithm.
		//For sorting in Ascending order, use > operator. For desceding order, use < operator.
		return (o1.getIsbnNo() < o2.getIsbnNo())?1:-1;
	}
}
