package ComparableImplementation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.TreeSet;

public class ComparableExample {
	public static void main(String[] args) {
		TreeSet <Book> books  = new TreeSet();
		Book b1=new Book(100, "9 planets", "Jonathan Stark");
		Book b2=new Book(101, "NGOs in India", "Dr Subramanya Swamy");
		Book b3=new Book(102, "Delhi Ages", "Manish Mahajan");
		
		books.add(b2); 
		books.add(b3); 
		books.add(b1);
		
		System.out.println("Books after Ascending sorting : " + books);

	}
}
