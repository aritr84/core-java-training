package ComparableImplementation;
public class Book implements Comparable<Book>{
	int isbnNo; String title; String authorName;

	Book(){
	}
	
	public Book(int isbnNo, String title, String authorName) {
		super();
		this.isbnNo = isbnNo;
		this.title = title;
		this.authorName = authorName;
	}

	public int getIsbnNo() {
		return isbnNo;
	}

	public void setIsbnNo(int isbnNo) {
		this.isbnNo = isbnNo;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	@Override
	public String toString() {
		return "Book [isbnNo=" + isbnNo + ", title=" + title + ", authorName=" + authorName + "]";
	}

	//Sort Ascending
	@Override
	public int compareTo(Book o) {
		return (this.getIsbnNo() > o.getIsbnNo())?1:-1;
	}
}
